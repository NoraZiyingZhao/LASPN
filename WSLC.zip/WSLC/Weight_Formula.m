function W = Weight_Formula(G, N, DC)

    Wij = zeros(N,N);
    for i = 1 : N
        for j = 1 : N
            if (i~=j)
    %             Wij(i,j) = length(intersect(find(A(i,:)),find(A(j,:))));% Weight formula
                  Wij(i,j) = (2*DC(i)*DC(j))/(DC(i)+DC(j));
            end
        end
    end
    W = ones(N,N);
    for i = 1 : N
        for j = 1 : N
            if (i~=j)
                P = shortestpath(G, i,j);
                for k = 1: length(P)-1
                    W(i,j) = W(i,j) * Wij(P(k),P(k+1));
                end
                W(i,j) = W(i,j) * (0.5^length(P));
            else
                W(i,j)=0;
            end
        end
    end
end