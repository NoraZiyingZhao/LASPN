function WSLC = WSLC_Metric(G, N, M, W, DC, L)

% Definition 1: Local-Influence
    for i = 1 : N
        Q_Local(i) = DC(i)/N;
    end
    
% Definition 2: Semi-Local-Influence
    Q_Semi_Local = zeros(1,N);
    d = distances(G);
    for i = 1 : N
        AllNeighbors=0;
        for l = 1 : L
            Neighbors = find(d(i,:)==l);
            for j = Neighbors
                a=W(i,j); b = DC(i); c=DC(j); e = d(i,j);
                Q_Semi_Local(i) = Q_Semi_Local(i) + sqrt( ((a*b)))/((b+c)*e) ;

            end
            AllNeighbors = AllNeighbors + length(Neighbors);
        end
        Q_Semi_Local(i)=Q_Semi_Local(i)/AllNeighbors;
    end
    
% Definition 3: LRASP-Influence
    for i = 1 : N
        Gv = [i];
        AllNode = 1:N;
        for l = 1 : L
            Gv = [Gv find(d(i,:)==l)];        
        end
        Nv = length(Gv);
        Gv = setdiff(AllNode,Gv);
        HGv = rmnode(G,Gv);
        dv = distances(HGv);
        diameter = max(max(dv));
        ASP_Gv = sum(sum(dv)) / (Nv*(Nv-1));
        HGvv = rmnode(HGv,i);
        Nvv = Nv - 1;
        dvv = distances(HGvv);
        dvv(dvv==inf) = diameter;
        ASP_Gvv = sum(sum(dvv)) / (Nvv*(Nvv-1));
        Q_LRASP(i) = (abs(ASP_Gv - ASP_Gvv)) / ASP_Gv;  

        R0 =N*M;
        R1=numedges(HGv)*Nv;
        R2=numedges(HGvv)*Nvv;
        Siz= abs(R1-R2)/R1;
        Q_LRASP(i)=Siz*exp(Q_LRASP(i) * ((R1/R0)^(2*L)));
    end

% Definition 4: Total-Influence
    alfa=0.33; beta = 0.33; gama= 0.33;
    for i = 1 : N
        WSLC(i) = alfa*Q_Local(i)+beta*Q_Semi_Local(i)+gama*Q_LRASP(i);
    end

end