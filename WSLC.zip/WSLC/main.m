clc;
clear;

%% Load graph
% net = xlsread('dataset/Graph1.xlsx');
% net = xlsread('dataset/Graph2.xlsx');
% net = xlsread('dataset/Graph3.xlsx');
net = load('dataset/karate.mtx'); % Karate club
% net = load('dataset/ia-infect-dublin.mtx'); % Infect-Dub
% net = load('dataset/web-polblogs.mtx'); % Web-Polblogs
% net = load('dataset/bio-dmela.mtx'); % Bio-Dmela
% net = load('dataset/USAir97.mtx'); % USAir97
% net = load('dataset/ca-AstroPh.mtx'); % Ca-AstroPh

%% Parameters
N = max(max(net));
M = length(net);
Nodes = 1 : N;
TopK = min(10,N);

%% Adjacency matrix
A = zeros(N,N);
for i = 1 : M
    x = net(i,1);
    y = net(i,2);
    A(x,y) = 1;
    A(y,x) = 1;
end

%% Create Graph
G = graph(A);
f = figure; 
plot(G);

%% Degree centrality
DC = zeros(1,N);
for i = 1 : N
    DC(i) = degree(G,i);
end
[value, rank] = sort(DC,'descend');
VarNames = {'Rank', 'DC'};
T = table(rank(1:TopK)',value(1:TopK)', 'VariableNames',VarNames);
disp(T);
data = rank(1:TopK)';
data = [data value(1:TopK)'];

%% Betweenness Centrality
BC = centrality(G, 'betweenness');
[value, rank] = sort(BC,'descend');
VarNames = {'Rank', 'BC'};
T = table(rank(1:TopK),value(1:TopK), 'VariableNames',VarNames);
disp(T);
data = [data rank(1:TopK)];
data = [data value(1:TopK)];

%% closeness Centrality
CC = centrality(G, 'closeness');
[value, rank] = sort(CC,'descend');
VarNames = {'Rank', 'CC'};
T = table(rank(1:TopK),value(1:TopK), 'VariableNames',VarNames);
disp(T);
data = [data rank(1:TopK)];
data = [data value(1:TopK)];

%% Semi-local Centrality (SC) Measure
SC = zeros(1,N);
for i = 1 : N
    SC(i) = SC_Metric(G, i, N);
end
[value, rank] = sort(SC,'descend');
VarNames = {'Rank', 'SC'};
T = table(rank(1:TopK)',value(1:TopK)', 'VariableNames',VarNames);
disp(T);
data = [data rank(1:TopK)'];
data = [data value(1:TopK)'];

%% average shortest path centrality (ASP) measures
ASP = zeros(1,N);
for i = 1 : N
    ASP(i) = ASP_Metric(G, i, N, A);
end
[value, rank] = sort(ASP,'descend');
VarNames = {'Rank', 'ASP'};
T = table(rank(1:TopK)',value(1:TopK)', 'VariableNames',VarNames);
disp(T);
data = [data rank(1:TopK)'];
data = [data value(1:TopK)'];

%% INASP measures
INASP = zeros(1,N);
for i = 1 : N
    INASP(i) = INASP_Metric(SC(i), ASP(i));
end
[value, rank] = sort(INASP,'descend');
VarNames = {'Rank', 'INASP'};
T = table(rank(1:TopK)',value(1:TopK)', 'VariableNames',VarNames);
disp(T);
data = [data rank(1:TopK)'];
data = [data value(1:TopK)'];

%% WSLC measures
L = 2;
W = Weight_Formula(G, N, DC);
WSLC = WSLC_Metric(G, N, M, W, DC, L);
[value, rank] = sort(WSLC,'descend');
VarNames = {'Rank', 'WSLC'};
T = table(rank(1:TopK)',value(1:TopK)', 'VariableNames',VarNames);
disp(T);
data = [data rank(1:TopK)'];
data = [data value(1:TopK)'];
xlswrite('data.xlsx',data);

