function AC = ASP_Metric(G, i, N, A)
    d = distances(G); % Calculate the shortest path distance between all node pairs
    ASP = (1/(N*(N-1))) * sum(sum(d));
    diameter = max(max(d));
    Adj = A;
    ng = neighbors(G,i);
    Adj(i,ng) = 0;
    Adj(ng,i) = 0;
    G1 = graph(Adj);
    d = distances(G1);
    d(d==inf) = diameter;
    ASPi = (1/(N*(N-1))) * sum(sum(d));

    AC = abs(ASPi - ASP) / ASP;
end