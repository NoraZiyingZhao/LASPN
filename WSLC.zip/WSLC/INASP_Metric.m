function INASP = INASP_Metric(SC, ASP)
    INASP = SC+ASP;%(2 * SLC * ASP) / (SLC + ASP); % Harmonic Mean
end