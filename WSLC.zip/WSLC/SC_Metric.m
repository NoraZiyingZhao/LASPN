function SC = SC_Metric(G, i, N)
    % Parameters
    alfa = 1;
    beta = 1;
    L = 3;
    
    D = alfa*degree(G,i);
    
    GIM = 0;
    for j = 1 : N
        if i == j, continue; end
        [~, dis] = shortestpath(G,i,j,'Method','positive'); % shortest path algorithm (Dijkstra)
        if dis <= L
            GIM = GIM + ((degree(G,j) * beta) / dis);
        end
    end
    
    SLC = D + GIM;
    SC = SLC / (L*N);
end    